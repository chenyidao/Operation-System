package opr_2;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Priority {
	
	ArrayList<PCB> storage= new ArrayList<PCB>();  //��Ž��̵Ķ�̬����
	//ArrayList<PCB>storageCopy = new ArrayList<PCB>();
	static int CPUTIME = 0;
	//��ʼ������
	public void initProcess()
	{
			PCB p1 = new PCB("P1",0,2,1,"ready");
			PCB p2 = new PCB("P2",0,3,5,"ready");
			PCB p3 = new PCB("P3",0,1,3,"ready");
			PCB p4 = new PCB("P4",0,2,4,"ready");
			PCB p5 = new PCB("P5",0,4,2,"ready");
			storage.add(p1);
			storage.add(p2);
			storage.add(p3);
			storage.add(p4);
			storage.add(p5);
			//storageCopy = storage;
			
	}
	
	//��ȡ����Ȩ���Ľ���
	public int getMax(List<PCB>list)
	{
		int max = -3;//������ȼ�
		int i = 0;
		int j = 0;
		Iterator<PCB>iterator = list.iterator();
		while(iterator.hasNext())
		{
			PCB pc = (PCB)iterator.next();
			if(pc.getPriority()>max&&(pc.getNeedTime()!=0))
			{
				max = pc.getPriority();
				j = i;
			}
			i++;
		}
		return j;
	}
	
	//���н��̺���Ӧ������Ȩ-1
	public void update_Priority(PCB pc)
	{
			pc.setPriority(pc.getPriority()-1);
	}
	
	//��ʾ��������״̬
	public void showProcess()
	{
		Iterator<PCB>iterator = storage.iterator();
		
		while(iterator.hasNext())
		{
			PCB pc = iterator.next();
			System.out.println(pc.getProcessName()+"    "+pc.getCpuTime()+"    "+pc.getNeedTime()+"    "+pc.getPriority()+"    "+pc.getState());
		}
		System.out.println();
	}
	
	//���н���
	public void run()
	{
		
		while(storage.get(getMax(storage)).getNeedTime()!=0)
		{
			CPUTIME++;
			System.out.println("CPUTIME:"+CPUTIME);
			int max = getMax(storage);
			PCB pc = storage.get(max);
			if(pc.getState().equals("finish"))
				break;
			if((pc.getNeedTime()-1)!=0)
			{
				pc.setState("working");
				pc.setNeedTime(pc.getNeedTime()-1);
				update_Priority(pc);   //�������ȼ�
				storage.set(max, pc);//���������ȼ����PCB�滻ԭ����PCB
			
				Iterator<PCB>iterator = storage.iterator();
				while(iterator.hasNext())
				{
					PCB p = (PCB)iterator.next();
					if(p.getState().equals("working"))
					{
						p.setCpuTime(p.getCpuTime()+1);
					}
					else if(!p.getState().equals("finish"))
					{
						p.setCpuTime(p.getCpuTime()+1);
					}
				}
					
				showProcess();		
				pc.setState("ready");
				//pc.setCpuTime(pc.getCpuTime()+1);
			}
			else
			{
				pc.setState("working");
				pc.setNeedTime(pc.getNeedTime()-1); //����ʱ��-1
				pc.setState("finish");
				update_Priority(pc);   //�������ȼ�
				storage.set(max, pc);//���������ȼ����PCB�滻ԭ����PCB
				showProcess();
				//pc.setCpuTime(pc.getCpuTime()+1);
			}
			//update_Priority(pc);   //�������ȼ�
			//storage.set(max, pc);//���������ȼ����PCB�滻ԭ����PCB
			if(pc.getNeedTime() <= 0)
			{
				//System.out.println("  ����"+pc.getProcessName()+"  ����");
				//storage.remove(max);
				pc.setState("finish");
			}
			System.out.println();
		}
	}
	
	public void Round_and_Waiting_Time()
	{
		Iterator<PCB>iterator = storage.iterator();
			PCB p1 = iterator.next();
			PCB p2 = iterator.next();
			PCB p3 = iterator.next();
			PCB p4 = iterator.next();
			PCB p5 = iterator.next();
			System.out.println(p1.getProcessName()+"    "+p1.getCpuTime()+"    "+(p1.getCpuTime()-2));
			System.out.println(p2.getProcessName()+"    "+p2.getCpuTime()+"    "+(p2.getCpuTime()-3));
			System.out.println(p3.getProcessName()+"    "+p3.getCpuTime()+"    "+(p3.getCpuTime()-1));
			System.out.println(p4.getProcessName()+"    "+p4.getCpuTime()+"    "+(p4.getCpuTime()-2));
			System.out.println(p5.getProcessName()+"    "+p5.getCpuTime()+"    "+(p5.getCpuTime()-4));
			//System.out.println(pc.getProcessName()+"    "+pc.getCpuTime()+"    "+(pc.getCpuTime()-pc.getNeedTime()));
	}
	
	
	class PCB{
		private String processName;
		private int CpuTime;
		private int NeedTime;
		private int priority;
		private String state;
		public PCB(String processName,int CpuTime, int NeedTime,int priority,String state)
		{
			this.processName = processName;
			this.CpuTime = CpuTime;
			this.NeedTime = NeedTime;
			this.priority = priority;
			this.state = state;
		}
		
		public void setProcessName(String processName)
		{
			this.processName = processName;
		}
		
		public void setCpuTime(int CpuTime)
		{
			this.CpuTime = CpuTime;
		}
		
		public void setNeedTime(int NeedTime)
		{
			this.NeedTime = NeedTime;
		}
		
		public void setPriority(int priority)
		{
			this.priority = priority;
		}
		
		public void setState(String state)
		{
			this.state = state;
		}
		
		public String getProcessName()
		{
			return processName;
		}
		
		public int getCpuTime()
		{
			return CpuTime;
		}
		
		public int getNeedTime()
		{
			return NeedTime;
		}
		
		public int getPriority()
		{
			return priority;
		}
		
		public String getState()
		{
			return state;
		}
		
	}
	public static void main(String[] args) {
		System.out.println("************************************");
		System.out.println("OUTPUT OF PRIORITY");
		System.out.println("NAME"+"  "+"CPUTIME"+"  "+"NEEDTIME"+"  "+"PRIORITY"+"  "+"STATE");
		System.out.println("CPUTIME:"+CPUTIME);
		Priority pr = new Priority();
		pr.showProcess();
		pr.initProcess();
		pr.showProcess();
		pr.run();
		System.out.println("NAME"+"  "+"RoundTime"+"  "+"WaitingTime");
		pr.Round_and_Waiting_Time();
		System.out.println("************************************");
	}
}
