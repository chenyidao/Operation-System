package opr_3;

import java.util.ArrayList;
import java.util.Scanner;

import opr_3.Simulate_Paging.*;

public class FIFI_Simulate_Paging {
	ArrayList<Page>list1 = new ArrayList<>();
	static int po;//���б��
	static final int SizeOfPage = 100;
	static final int SizeOfBlock = 128;
	static final int M = 4;
	static int P[];
	public void initPage_Table()
	{
		Simulate_Paging s = new Simulate_Paging();
		P = new int[M];
		Page p0 = s.new Page();
		p0.setNumber_of_page(0);
		p0.setFlag(1);
		p0.setMemory_block(5);
		p0.setLocation(011);
		p0.setModify(0);
		Page p1 = s.new Page();
		p1.setNumber_of_page(1);
		p1.setFlag(1);
		p1.setMemory_block(8);
		p1.setLocation(012);
		p1.setModify(0);
		Page p2 = s.new Page();
		p2.setNumber_of_page(2);
		p2.setFlag(1);
		p2.setMemory_block(9);
		p2.setLocation(013);
		p2.setModify(0);
		Page p3 = s.new Page();
		p3.setNumber_of_page(3);
		p3.setFlag(1);
		p3.setMemory_block(1);
		p3.setLocation(021);
		p3.setModify(0);
		Page p4 = s.new Page();
		p4.setNumber_of_page(4);
		p4.setFlag(0);
		p4.setLocation(022);
		p4.setModify(0);
		Page p5 = s.new Page();
		p5.setNumber_of_page(5);
		p5.setFlag(0);
		p5.setLocation(023);
		p5.setModify(0);
		Page p6 = s.new Page();
		p6.setNumber_of_page(6);
		p6.setFlag(0);
		p6.setLocation(121);
		p6.setModify(0);
		list1.add(p0);
		list1.add(p1);
		list1.add(p2);
		list1.add(p3);
		list1.add(p4);
		list1.add(p5);
		list1.add(p6);
		P[0] = 0;
		P[1] = 1;
		P[2] = 2;
		P[3] = 3;
	}
	public static void main(String[] args) {
		FIFI_Simulate_Paging fsp = new FIFI_Simulate_Paging();
		fsp.initPage_Table();
		int page,unit;
		String choice;
		boolean run = false;
		//��FIFOҳ������㷨����ȱҳ�ж�
		do
		{
			System.out.println("������ָ���ҳ�š���Ԫ���Լ��Ƿ�Ϊ��ָ��");
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			page = sc.nextInt();
			unit = sc.nextInt();
			choice = sc.next();
			if(page<0||unit<0)
				run = false;
			else 
			{
				if((fsp.list1.get(page).getFlag()!=0))
				{
					//System.out.println(sp.list.get(page).getNumber_of_page());
					System.out.println("���Ե�ַΪ = "+(fsp.list1.get(page).getNumber_of_page()*SizeOfBlock+unit));
					if(choice=="Y"||choice=="y")
						fsp.list1.get(page).setModify(1);
				}
				else
				{
					int n = P[po];
					if(fsp.list1.get(n).getModify()!=0)
					{
						fsp.list1.get(n).setModify(0);
					}
					fsp.list1.get(n).setFlag(0);
					System.out.println("�滻��ҳ��:"+P[po]);
					System.out.println("�Ƶ������е�ҳ��:"+page);
					fsp.list1.get(page).setMemory_block(fsp.list1.get(n).getMemory_block());
					fsp.list1.get(page).setFlag(1);
					P[po] = page;
					po = (po+1)%M;
					//System.out.println("*"+page);
					//System.out.println(111);
				}
			}
		}while(!run);
		System.out.println("����P��ֵΪ:");
		for(int i = 0;i<M;i++)
		{
			System.out.println(P[i]);
		}
	}
}
