package opr_3;

import java.util.ArrayList;
import java.util.Scanner;

public class Simulate_Paging {
	static final int SizeOfPage = 100;
	static final int SizeOfBlock = 128;
	ArrayList<Page>list = new ArrayList<Page>();
	//int p[];
	public void initPage_Table()
	{
		Page p0 = new Page();
		p0.setNumber_of_page(0);
		p0.setFlag(1);
		p0.setMemory_block(5);
		p0.setLocation(011);
		Page p1 = new Page();
		p1.setNumber_of_page(1);
		p1.setFlag(1);
		p1.setModify(0);
		p1.setMemory_block(8);
		p1.setLocation(012);
		Page p2 = new Page();
		p2.setNumber_of_page(2);
		p2.setFlag(1);
		p2.setMemory_block(9);
		p2.setLocation(013);
		p2.setModify(0);
		Page p3 = new Page();
		p3.setNumber_of_page(3);
		p3.setFlag(1);
		p3.setMemory_block(1);
		p3.setLocation(021);
		p3.setModify(0);
		Page p4 = new Page();
		p4.setNumber_of_page(4);
		p4.setFlag(0);
		p4.setLocation(022);
		p4.setModify(0);
		Page p5 = new Page();
		p5.setNumber_of_page(5);
		p5.setFlag(0);
		p5.setLocation(023);
		p5.setModify(0);
		Page p6 = new Page();
		p6.setNumber_of_page(6);
		p6.setFlag(0);
		p6.setLocation(121);
		p6.setModify(0);
		list.add(p0);
		list.add(p1);
		list.add(p2);
		list.add(p3);
		list.add(p4);
		list.add(p5);
		list.add(p6);
	}
	class Page
	{
		private int number_of_page;
		private int flag;
		private int memory_block;
		private int location;
		private int modify;
		public int getModify() {
			return modify;
		}

		public void setModify(int modify) {
			this.modify = modify;
		}

		public Page(int number_of_page,int flag,int memory_block,int location) 
		{
			this.number_of_page = number_of_page;
			this.flag = flag;
			this.memory_block = memory_block;
			this.location = location;
		}
		
		public Page()
		{
			this.number_of_page = 0;
			this.flag = 0;
			this.memory_block = 0;
			this.location = 0;
			this.modify = 0;
		}
		
		public int getNumber_of_page() {
			return number_of_page;
		}
		public void setNumber_of_page(int number_of_page) {
			this.number_of_page = number_of_page;
		}
		public int getFlag() {
			return flag;
		}
		public void setFlag(int flag) {
			this.flag = flag;
		}
		public int getMemory_block() {
			return memory_block;
		}
		public void setMemory_block(int memory_block) {
			this.memory_block = memory_block;
		}
		public int getLocation() {
			return location;
		}
		public void setLocation(int location) {
			this.location = location;
		}
		
	}
	
	public static void main(String[] args) {
		Simulate_Paging sp= new Simulate_Paging();
		sp.initPage_Table();
		boolean run = false;
		int page,unit;
		do
		{
			System.out.println("������ָ���ҳ�ź͵�Ԫ��");
			@SuppressWarnings("resource")
			Scanner sc  = new Scanner(System.in);
			page = sc.nextInt();
			unit = sc.nextInt();
			//System.out.println(page);
			//System.out.println(unit);
			if(page<0||unit<0)
				run = false;
			else 
			{
				if((sp.list.get(page).getFlag()!=0))
				{
					//System.out.println(sp.list.get(page).getNumber_of_page());
					System.out.println("���Ե�ַΪ = "+(sp.list.get(page).getNumber_of_page()*SizeOfBlock+unit));
				}
				else
				{
					System.out.println("*"+page);
					//System.out.println(111);
				}
			}
		}while(!run);
	
	}
	
	
	
}
