package opr_1;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import opr_1.DataDemo.Plant;

public class Test {
	public static void main(String[] args) {
		DataDemo test = new DataDemo();
		Plant plant = test.new Plant();
		ExecutorService service = Executors.newCachedThreadPool();
		Producer producer1 = new Producer("������001",plant);
		Producer producer2 = new Producer("������002",plant);
		Consumer consumer = new Consumer("������001",plant);
		service.submit(producer1);
		service.submit(producer2);
		service.submit(consumer);
	}
}
