package opr_4;

import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		File_System fs = new File_System();
		fs.initMU();
		//fs.showMDF();
		//fs.showUFD(fs.currentUser);
		//fs.ReadFile();
		//fs.WriteFile();
		//fs.DeleteFile();
		//fs.CloseFile();
		//fs.CreateFile();
		int choice;
		if(fs.SearchLogin()==1)
		{
			while(true)
			{
				fs.MainMenu();
				Scanner sc = new Scanner(System.in);
				choice = sc.nextInt();
				switch(choice)
				{
					case 1:
						fs.showMDF();
						break;
					case 2:
						fs.showUFD(fs.currentUser);
						break;
					case 3:
						fs.CreateFile();
						break;
					case 4:
						fs.OpenFile();
						break;
					case 5:
						fs.ReadFile();
						break;
					case 6:
						fs.WriteFile();
						break;
					case 7:
						fs.CloseFile();
						break;
					case 8:
						fs.DeleteFile();
						break;
					case 0:return;
					default:
						System.out.println("����ȷ�������ָ��");
				}
			}
		}
	}
}
